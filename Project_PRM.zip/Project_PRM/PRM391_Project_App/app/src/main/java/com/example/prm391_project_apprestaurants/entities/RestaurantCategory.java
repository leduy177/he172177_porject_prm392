package com.example.prm391_project_apprestaurants.entities;

public class RestaurantCategory {
    private int restaurantId;
    private int categoryId;

    public int getRestaurantId() {

        return restaurantId;
    }

    public void setRestaurantId(int restaurantId) {
        this.restaurantId = restaurantId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
}
