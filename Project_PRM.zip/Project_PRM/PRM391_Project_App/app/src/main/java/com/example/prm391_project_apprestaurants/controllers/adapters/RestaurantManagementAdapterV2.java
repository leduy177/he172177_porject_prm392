package com.example.prm391_project_apprestaurants.controllers.adapters;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.prm391_project_apprestaurants.controllers.viewholders.BindingViewHolder;
import com.example.prm391_project_apprestaurants.databinding.ViewholderRestaurantItemV2Binding;

public class RestaurantManagementAdapterV2 extends RecyclerView.Adapter<BindingViewHolder<ViewholderRestaurantItemV2Binding>>{
    @NonNull
    @Override
    public BindingViewHolder<ViewholderRestaurantItemV2Binding> onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull BindingViewHolder<ViewholderRestaurantItemV2Binding> holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }
}
